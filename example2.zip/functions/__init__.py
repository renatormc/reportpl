
class Functions:
    # @staticmethod
    # def triple(value, parm1, parm2):
    #     return 3*value
    pass

