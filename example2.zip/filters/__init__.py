
class Filters:
    @staticmethod
    def quote(value):
        return f"\"{value}\""

  
